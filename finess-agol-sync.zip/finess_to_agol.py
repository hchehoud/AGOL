import requests
import pandas as pd
import time
from arcgis.gis import GIS
from arcgis.features import FeatureLayer
from dotenv import load_dotenv
import os

load_dotenv()

FINESS_API_URL = "https://data.sante.gouv.fr/api/records/1.0/search/?dataset=finess-etablissements&rows=20000"

AGOL_USERNAME = os.getenv("AGOL_USERNAME")
AGOL_PASSWORD = os.getenv("AGOL_PASSWORD")
FEATURE_LAYER_URL = os.getenv("FEATURE_LAYER_URL")

def load_finess():
    print("📥 Chargement des données FINESS...")
    response = requests.get(FINESS_API_URL)
    response.raise_for_status()
    data = response.json()
    records = [rec["fields"] for rec in data["records"]]
    df = pd.DataFrame(records)
    print(f"✔ {len(df)} établissements chargés.")
    return df

def geocode_address(address):
    try:
        url = "https://api-adresse.data.gouv.fr/search/"
        params = {"q": address, "limit": 1}
        r = requests.get(url, params=params).json()
        if r["features"]:
            geom = r["features"][0]["geometry"]["coordinates"]
            return geom[0], geom[1]
    except:
        pass
    return None, None

def geocode_dataframe(df):
    print("🧭 Géocodage des adresses...")
    xs, ys = [], []
    for addr in df["adresse"]:
        x, y = geocode_address(addr + ", France")
        xs.append(x)
        ys.append(y)
        time.sleep(0.05)
    df["x"] = xs
    df["y"] = ys
    print(f"✔ Géocodage terminé : {df['x'].notna().sum()}/{len(df)} adresses")
    return df

def update_agol(df):
    print("🔐 Connexion à ArcGIS Online...")
    gis = GIS("https://www.arcgis.com", AGOL_USERNAME, AGOL_PASSWORD)
    fl = FeatureLayer(FEATURE_LAYER_URL)
    print("📤 Envoi des données vers ArcGIS Online...")
    features = []
    for _, row in df.iterrows():
        if pd.isna(row["x"]) or pd.isna(row["y"]):
            continue
        feature = {"geometry": {"x": row["x"], "y": row["y"]}, "attributes": row.to_dict()}
        features.append(feature)
    print(f"➕ Ajout de {len(features)} entités...")
    result = fl.edit_features(adds=features)
    print("✔ Mise à jour terminée.")
    print(result)

def main():
    df = load_finess()
    df = geocode_dataframe(df)
    update_agol(df)

if __name__ == "__main__":
    main()
